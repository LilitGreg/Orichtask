import { Directive } from '@angular/core';

@Directive({
  selector: '[appPanel]'
})
export class PanelDirective {

  constructor() { }

}
