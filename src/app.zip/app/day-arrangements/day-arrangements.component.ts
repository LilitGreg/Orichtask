import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day-arrangements',
  templateUrl: './day-arrangements.component.html',
  styleUrls: ['./day-arrangements.component.css']
})
export class DayArrangementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
