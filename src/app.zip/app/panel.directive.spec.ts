import { PanelDirective } from './panel.directive';

describe('PanelDirective', () => {
  it('should create an instance', () => {
    const directive = new PanelDirective();
    expect(directive).toBeTruthy();
  });
});
